
#ifndef PERF_H_INCLUDED
#define PERF_H_INCLUDED

#define PERF_START	/* NULL definition */
#define PERF_STOP(x)	/* NULL definition */

#endif /* PERF_H_INCLUDED */
