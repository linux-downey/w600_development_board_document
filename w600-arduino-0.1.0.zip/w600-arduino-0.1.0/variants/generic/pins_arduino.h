#ifndef _PINS_ARDUINO_H_
#define _PINS_ARDUINO_H_

#include "wm_io.h"

#include "variant.h"

#if NUM_ANALOG_INPUTS > 0
#define PIN_A1	WM_IO_PA_01
#endif

#if NUM_ANALOG_INPUTS > 1
#define PIN_A4	(WM_IO_PA_04)
#endif

#if NUM_ANALOG_INPUTS > 2
#define PIN_A5	(WM_IO_PA_05)
#endif

#if NUM_ANALOG_INPUTS > 3
#define PIN_B6	(WM_IO_PB_06)
#endif

#if NUM_ANALOG_INPUTS > 4
#define PIN_B7	(WM_IO_PB_07)
#endif

#if NUM_ANALOG_INPUTS > 5
#define PIN_B8	(WM_IO_PB_08)
#endif

#if NUM_ANALOG_INPUTS > 6
#define PIN_B9	(WM_IO_PB_09)
#endif

#if NUM_ANALOG_INPUTS > 7
#define PIN_B10	(WM_IO_PB_10)
#endif

#if NUM_ANALOG_INPUTS > 8
#define PIN_B11	(WM_IO_PB_11)
#endif

#if NUM_ANALOG_INPUTS > 9
#define PIN_B12	(WM_IO_PB_12)
#endif

#define LED_BUILTIN WM_IO_PB_17
#define LED_RED     WM_IO_PB_16
#define LED_GREEN   LED_BUILTIN
#define LED_BLUE    WM_IO_PB_18

#define TLS_UART1_MUL_RX	WM_IO_PB_17
#define TLS_UART1_MUL_TX	WM_IO_PB_18

#define PWM1 WM_IO_PB_18
#define PWM2 WM_IO_PB_17
#define PWM3 WM_IO_PB_16
#define PWM4 WM_IO_PB_15
#define PWM5 WM_IO_PB_14

#endif
