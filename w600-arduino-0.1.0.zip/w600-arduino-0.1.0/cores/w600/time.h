#ifndef TIME_H_
#define TIME_H_

#ifdef __cplusplus
extern "C" {
#endif

#define time_t long

void configTime(int timezone, int daylightOffset_sec, const char* server1, const char* server2, const char* server3);
time_t time(time_t * t);

#ifdef __cplusplus
}
#endif

#endif /* TIME_H_ */
