#include <stdio.h>

#include "pins_arduino.h"
#include "HardwareSerial.h"
#include "wiring_time.h"

extern "C" {
#include "wm_uart.h"
#include "wm_osal.h"
#include "wm_gpio_afsel.h"
}

volatile bool _uart1_mul_init_flag = false;

HardwareSerial Serial(0);
HardwareSerial Serial1(1);
HardwareSerial SerialM1(1, true);

unsigned char _serial_buf[TLS_UART_RX_BUF_SIZE] = {0};
unsigned char _serial1_buf[TLS_UART_RX_BUF_SIZE] = {0};
int _s_buf_begin = 0;
int _s_buf_end = 0;
int _s1_buf_begin = 0;
int _s1_buf_end = 0;

#define TEST_DEBUG  0

extern "C" int sendchar(int ch);

extern "C" signed short uart_rx_cb(u16 uart_no, unsigned short len,
    unsigned char * pbuf, int *pend)
{
    int ret = 0;
    int _len = 0;
    do
    {
        ret = tls_uart_read(uart_no, pbuf + *pend, 1);
        if (ret > 0)
            (*pend) = *pend + ret;
        _len += ret;
    } while (ret != 0);
}

extern "C" signed short uart1_rx_cb(unsigned short len)
{
    return uart_rx_cb(TLS_UART_1, len, _serial1_buf, &_s1_buf_end);
}

extern "C" signed short uart0_rx_cb(unsigned short len)
{
    return uart_rx_cb(TLS_UART_0, len, _serial_buf, &_s_buf_end);
}

int _read_byte(unsigned char *buf, int *begin, int *end)
{
    int c = 0;
    if (*begin < TLS_UART_RX_BUF_SIZE
        && *begin < *end)
    {
        c = (int)(buf[*begin]);
    }
    return c;
}

HardwareSerial::HardwareSerial(int serial_no)
{
    HardwareSerial(serial_no, false);
}

HardwareSerial::HardwareSerial(int serial_no, bool mul_flag)
{
    _uart_no = serial_no;
    _uart1_mul = mul_flag;
#if USE_SEM
    tls_os_sem_create(&_psem, _uart_no);
#endif

    if (TLS_UART_0 == _uart_no)
    {
        _pbegin = &_s_buf_begin;
        _pend = &_s_buf_end;
        _pbuf = _serial_buf;
    } else if (TLS_UART_1 == _uart_no) {
        _pbegin = &_s1_buf_begin;
        _pend = &_s1_buf_end;
        _pbuf = _serial1_buf;
    }
}

void HardwareSerial::begin(unsigned long baud, int modeChoose)
{
#if USE_SEM
    if (TLS_UART_0 == _uart_no)
        tls_os_sem_create(&_psem, 1);
    else if (TLS_UART_1 == _uart_no && NULL != _psem)
        tls_os_sem_create(&_psem, 1);
#endif
    if (TLS_UART_1 == _uart_no 
        && 1 == _uart1_mul)
    {
        wm_uart1_rx_config(TLS_UART1_MUL_RX);
        wm_uart1_tx_config(TLS_UART1_MUL_TX);
        _uart1_mul_init_flag = 1;
    }
    
    tls_uart_port_init(_uart_no, NULL, modeChoose);
    if (TLS_UART_1 == _uart_no)
        tls_uart_rx_callback_register(TLS_UART_1, uart1_rx_cb);
    else if (TLS_UART_0 == _uart_no)
    {
        tls_uart_rx_callback_register(TLS_UART_0, uart0_rx_cb);
    }
}

void HardwareSerial::begin()
{
    begin(115200);
}

void HardwareSerial::begin(unsigned long baud)
{
    begin(baud, 0);
}

void HardwareSerial::set_uart_no(int uart_no)
{
    //_uart_no = uart_no;
}

int HardwareSerial::read(void)
{
    int len = 0;
    int c = 0;

    c = _read_byte(_pbuf, _pbegin, _pend);
    if (0 != c)
    {
        (*_pbegin) = (*_pbegin) + 1;
    }
    return c;
}

int HardwareSerial::peek()
{
    int len = 0;
    int c = 0;

    c = _read_byte(_pbuf, _pbegin, _pend);
    
    return c;
}

size_t HardwareSerial::write(uint8_t c)
{
    int ret = 0;
    AR_DBG();
    
    if (TLS_UART_1 == _uart_no
        && 1 == _uart1_mul
        && 0 == _uart1_mul_init_flag)
    {
        wm_uart1_rx_config(TLS_UART1_MUL_RX);
        wm_uart1_tx_config(TLS_UART1_MUL_TX);
        _uart1_mul_init_flag = 1;
    }
    ret = tls_uart_write(_uart_no, (char *)&c, 1);
    return 1;
}

int HardwareSerial::available(void)
{
    if (*_pend >= *_pbegin)
        return (*_pend - *_pbegin);
    return TLS_UART_RX_BUF_SIZE - (*_pbegin - *_pend) - 1;
}
