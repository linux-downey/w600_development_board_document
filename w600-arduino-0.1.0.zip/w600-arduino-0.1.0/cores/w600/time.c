#include <string.h>

#include "wm_wifi.h"
#include "wm_ntp.h"
#include "wm_netif.h"
#include "time.h"

#define UTC_NTP 2208988800U     /* 1970 - 1900 ;�� ������� */

int time_timezone = 8*3600;
int time_dayoff = 0;

static int isNetworkOk(void)
{
	struct tls_ethif* etherIf = tls_netif_get_ethif();

	return (WM_WIFI_JOINED == tls_wifi_get_state()
            && etherIf != NULL
            && etherIf->ip_addr.addr != 0);
}

void configTime(int timezone, int daylightOffset_sec,
        const char* server1,
        const char* server2,
        const char* server3)
{
	tls_ntp_set_server((char *)server1, 0);
	tls_ntp_set_server((char *)server1, 1);
	tls_ntp_set_server((char *)server1, 2);

	time_timezone = timezone;
	time_dayoff = daylightOffset_sec;
}

time_t time(time_t * t)
{
	time_t seconds;

    if(1 != isNetworkOk())
    {
       *t = -1;
       return -1;
    }

    seconds = tls_ntp_client();
	seconds = seconds
                - 8*3600
                + UTC_NTP
                + time_timezone
                + time_dayoff;
		
    if (t)
    {
        *t = seconds;
    }
    return seconds;
}
