#ifndef __WIRING_TIME_H_
#define __WIRING_TIME_H_

#include "stdint.h"

#ifdef __cplusplus
extern "C" {
#endif

extern unsigned int millis(void);
extern uint32_t micros(void);
extern void delay(unsigned long ms);
extern void delayMicroseconds(unsigned int us);

#ifdef __cplusplus
}
#endif

#endif
