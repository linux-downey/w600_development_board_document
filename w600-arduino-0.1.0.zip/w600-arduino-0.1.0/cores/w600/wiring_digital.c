#include "Arduino.h"

#ifdef __cplusplus
extern "C" {
#endif

#include "wm_gpio.h"

void pinMode(uint32_t ulPin, uint32_t ulMode)
{
	tls_gpio_cfg(ulPin,
        ulMode == INPUT 
        	? WM_GPIO_DIR_INPUT 
        	: WM_GPIO_DIR_OUTPUT, 
        	WM_GPIO_ATTR_PULLLOW);
}

void digitalWrite(uint32_t ulPin, uint32_t ulVal)
{
	tls_gpio_write(ulPin, ulVal);
}

int digitalRead(uint32_t ulPin)
{
	return tls_gpio_read(ulPin);
}

#ifdef __cplusplus
}
#endif
