#include "twi.h"
#include "pins_arduino.h"
#include "wiring_private.h"
#include "wm_i2c.h"
#include "wm_gpio_afsel.h"


unsigned int preferred_si2c_clock = 200000;
static unsigned char twi_sda, twi_scl;
static uint32_t twi_clockStretchLimit;


void twi_setClock(unsigned int freq){
  preferred_si2c_clock = freq;
}

void twi_init(unsigned char sda, unsigned char scl){
  twi_sda = sda;
  twi_scl = scl;
  
  wm_i2c_scl_config(twi_scl);
  wm_i2c_sda_config(twi_sda);
  tls_i2c_init(preferred_si2c_clock);
}

void twi_stop(void){
  tls_i2c_stop();
}

static bool twi_write_stop(void){
    
  tls_i2c_stop();
  return true;
}

static int twi_write_byte(unsigned char byte, unsigned char ifstart) {

  int ret;

  tls_i2c_write_byte(byte, ifstart);
  ret = tls_i2c_wait_ack();
  return ret;
}

static unsigned char twi_read_byte(bool nack) {

  unsigned char byte = 0;

  byte = tls_i2c_read_byte(nack, 0);
  return byte;
}

unsigned char twi_writeTo(unsigned char address, unsigned char * buf, unsigned int len, unsigned char sendStop){
  unsigned int i;

  if(twi_write_byte(address, 1)) {
    if (sendStop) 
      twi_write_stop();
    return 2; //received NACK on transmit of address
  }
  for(i=0; i<len; i++) {
    if(twi_write_byte(buf[i], 0)) {
      if (sendStop) 
        twi_write_stop();
      return 3;//received NACK on transmit of data
    }
  }
  if(sendStop) 
    twi_write_stop();

  return 0;
}

unsigned char twi_readFrom(unsigned char address, unsigned char* buf, unsigned int len, unsigned char sendStop){
  unsigned int i;

  if(twi_write_byte(address, 1)) {
    if (sendStop) 
      twi_write_stop();
    return 2;//received NACK on transmit of address
  }
  for(i=0; i<(len-1); i++) 
    buf[i] = twi_read_byte(false);
  buf[len-1] = twi_read_byte(true);
  if(sendStop) 
    twi_write_stop();
  
  return 0;
}

uint8_t twi_status() {           
    return I2C_OK;                       //all ok
}

