#ifndef _WIRING_CONSTANTS_#define _WIRING_CONSTANTS_
#define HIGH	0x01#define LOW		0x00
#define INPUT	0x00#define OUTPUT	0x01
enum BitOrder {    LSBFIRST = 0,    MSBFIRST = 1};#endif