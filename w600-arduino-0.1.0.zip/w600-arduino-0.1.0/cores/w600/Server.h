#ifndef _SERVER_H_
#define _SERVER_H_

#include "Print.h"

class Server : public Print
{
public:
    virtual void begin() = 0;
};

#endif