#ifndef Arduino_h
#define Arduino_h

#ifdef __cplusplus
extern "C" {
#endif

#include "wiring.h"
#include "pins_arduino.h"

#define PWMRANGE 255
void analogWrite(uint8_t pin, int val);
void analogWriteFreq(uint32_t freq);
unsigned long pulseIn(uint8_t pin, uint8_t state, unsigned long timeout);
unsigned long pulseInLong(uint8_t pin, uint8_t state, unsigned long timeout);

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus

void tone(uint8_t _pin, unsigned int frequency);
void noTone(uint8_t _pin);

#endif

#endif 
