#ifndef _HARDWARESERIAL_H_
#define _HARDWARESERIAL_H_

#include "debug.h"

#include "Stream.h"

#define USE_SEM 0

class HardwareSerial : public Stream
{
public:
    HardwareSerial(int serial_no);
    HardwareSerial(int serial_no, bool mul_flag);
    HardwareSerial() {}

	void begin();
    void begin(unsigned long baud);
    void begin(unsigned long baud, int modeChoose);
    void set_uart_no(int uart_no);
    virtual int read(void);         // from Stream
    virtual int available(void);    // from Stream
    virtual int peek();             // from Stream
public:
    virtual size_t write(uint8_t c); // from Print
    
private:
    int _uart_no;
    bool _uart1_mul;
    unsigned char *_pbuf;
    int *_pbegin; 
    int *_pend;
#if USE_SEM
    tls_os_sem_t * _psem;
#endif
};

extern HardwareSerial Serial;
extern HardwareSerial Serial1;
extern HardwareSerial SerialM1;

#endif
