#ifndef _IP_ADDRESS_H_
#define _IP_ADDRESS_H_

#include <stdint.h>
#include "Printable.h"
#include "WString.h"

class IPAddress : public Printable
{
private:
    union {
        uint8_t bytes[4];  // IPv4 address
        uint32_t dword;
    } _address;
    uint8_t *raw_address()
    {
        return _address.bytes;
    }

public:
    IPAddress();
    IPAddress(uint8_t first_oct, uint8_t sec_oct, uint8_t third_oct, uint8_t fourth_oct);
    IPAddress(uint32_t address);
    IPAddress(const uint8_t *address);

    operator uint32_t() const {
        return _address.dword;
    }
    bool operator==(const IPAddress& addr) const {
        return _address.dword == addr._address.dword;
    }
    bool operator==(uint32_t addr) const {
        return _address.dword == addr;
    }
    bool operator==(const uint8_t* addr) const;

    // Overloaded index operator to allow getting and setting individual octets of the address
    uint8_t operator[](int index) const {
        return _address.bytes[index];
    }
    uint8_t& operator[](int index) {
        return _address.bytes[index];
    }

    // Overloaded copy operators to allow initialisation of IPAddress objects from other types
    IPAddress& operator=(const uint8_t *address);
    IPAddress& operator=(uint32_t address);
    String toString() const;
    bool fromString(const char *address);
    bool fromString(const String &address);

    virtual size_t printTo(Print& p) const;
};

#endif//_IP_ADDRESS_H_