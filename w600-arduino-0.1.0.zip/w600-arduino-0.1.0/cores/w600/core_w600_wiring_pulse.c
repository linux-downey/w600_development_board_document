/**
 * @file    core_w600_wiring_pulse.cpp
 *
 * @brief   pulse Driver Module
 *
 * @author  
 *
 * Copyright (c) 2018 Winner Microelectronics Co., Ltd.
 */
#include <stdint.h>
#include "pins_arduino.h"
#include "wiring_digital.h"

extern uint32_t micros(void);
extern unsigned long xTaskGetTickCount( void );

#define WAIT_FOR_PIN_STATE(state) \
    while (digitalRead(pin) != (state)) { \
        if (micros() - startMicros > timeout) { \
            return 0; \
        } \
    }

/* Measures the length (in microseconds) of a pulse on the pin; state is HIGH
 * or LOW, the type of pulse to measure.  Works on pulses from 2-3 microseconds
 * to 3 minutes in length, but must be called at least a few dozen microseconds
 * before the start of the pulse.
 *
 * ATTENTION:
 * This function relies on micros() so cannot be used in noInterrupt() context
 */
unsigned long pulseIn(uint8_t pin, uint8_t state, unsigned long timeout)
{
    uint32_t startMicros = micros();
    
    WAIT_FOR_PIN_STATE(!state);
    WAIT_FOR_PIN_STATE(state);
    uint32_t start = micros();
    WAIT_FOR_PIN_STATE(!state);

    return (micros() - start);
}

unsigned long pulseInLong(uint8_t pin, uint8_t state, unsigned long timeout)
{
    return pulseIn(pin, state, timeout);
}
