#include "wm_osal.h"
#include "stdint.h"
#include "wm_regs.h"
#include "Wiring_time.h"

static inline uint32_t LL_SYSTICK_IsActiveCounterFlag(void)
{
  return ((SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk) == (SysTick_CTRL_COUNTFLAG_Msk));
}

unsigned int millis(void)
{
    return tls_os_get_time();
}

uint32_t micros(void)
{
  /* Ensure COUNTFLAG is reset by reading SysTick control and status register */
  LL_SYSTICK_IsActiveCounterFlag();
  uint32_t m = tls_os_get_time();
  uint32_t u = SysTick->LOAD - SysTick->VAL;
  if(LL_SYSTICK_IsActiveCounterFlag) {
    m = tls_os_get_time();
    u = SysTick->LOAD - SysTick->VAL;
  }
  return (uint32_t)( m * 2000 + (u * 1000) / SysTick->LOAD);
}

void delay(unsigned long ms)
{
    tls_os_time_delay(ms/2);
}

void delayMicroseconds(unsigned int us)
{
    unsigned int value = 1;
    unsigned int RegValue;
    volatile int i = 0, j = 0;

    RegValue = *(unsigned int *)(HR_CLK_DIV_CTL);
    //printf("\nRegVal=%d\n",RegValue&0x0000000f);
    switch (RegValue & 0x0000000F)
    {
    case 0x02: //80M
        value = us * 2;
        break;
    case 0x04: //40M
        value = us;
        break;
    }
    for (i = 0; i < value; i++)
    {
        for (j = 0; j < 7; j++)
        {
        }
    }
}
