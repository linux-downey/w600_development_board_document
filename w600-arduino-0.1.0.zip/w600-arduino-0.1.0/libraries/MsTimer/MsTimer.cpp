/**
 * @file    MsTimer.cpp
 *
 * @brief   MsTimer Driver Module
 *
 * @author  
 *
 * Copyright (c) 2018 Winner Microelectronics Co., Ltd.
 */
#include <MsTimer.h>

volatile unsigned char MsTimer1::timer_id;
volatile unsigned char MsTimer2::timer_id;

void MsTimer1::set(unsigned long ms, void (*f)()) {

    struct tls_timer_cfg timer_cfg;
    
    timer_cfg.unit = TLS_TIMER_UNIT_MS;
    timer_cfg.timeout = ms;
    timer_cfg.is_repeat = 1;
    timer_cfg.callback = (tls_timer_irq_callback)f;
    timer_cfg.arg = NULL;
    timer_id = tls_timer_create(&timer_cfg);
}

void MsTimer1::start() {

    tls_timer_start(timer_id);
}

void MsTimer1::stop() {

    tls_timer_stop(timer_id);
}

void MsTimer2::set(unsigned long ms, void (*f)()) {

    struct tls_timer_cfg timer_cfg;
    
    timer_cfg.unit = TLS_TIMER_UNIT_MS;
    timer_cfg.timeout = ms;
    timer_cfg.is_repeat = 1;
    timer_cfg.callback = (tls_timer_irq_callback)f;
    timer_cfg.arg = NULL;
    timer_id = tls_timer_create(&timer_cfg);
}

void MsTimer2::start() {

    tls_timer_start(timer_id);
}

void MsTimer2::stop() {

    tls_timer_stop(timer_id);
}


