#ifndef _DNS_CLIENT_H_
#define _DNS_CLIENT_H_

#include <stdint.h>

class DNSClient
{
public:
    void begin(unsigned int aDNSServer);
    void begin(const char *aDNSServer);

    int getHostByName(const char *aHostname, unsigned int &aResult);
    int getHostByName(const char *aHostname, char *&aResult);

protected:
    uint16_t BuildRequest(const char *aName);
    uint16_t ProcessResponse(uint16_t aTimeout, uint32_t &aAddress);
};

#endif
