/**
 * @file    SPI.cpp
 *
 * @brief   SPI Driver Module
 *
 * @author
 *
 * Copyright (c) 2018 Winner Microelectronics Co., Ltd.
 */
#include "SPI.h"

SPIClass SPI;

/**
  * @brief  Initialize the SPI instance.
  */
void SPIClass::begin(void)
{
}

/**
  * @brief  This function should be used to configure the SPI instance in case you
  *         don't use the default parameters set by the begin() function.
  * @param  settings: SPI settings(clock speed, bit order, data mode).
  * note    don't call after SPIClass::begin();
  */
void SPIClass::beginTransaction(SPISettings settings)
{
  tls_spi_setup(settings.dMode, TLS_SPI_CS_LOW, settings.clk);

  if (settings.bOrder == MSBFIRST)
  {
    spi_set_endian(1);
  }
  else
  {
    spi_set_endian(0);
  }
}

/**
  * @brief settings associated to the SPI instance.
  */
void SPIClass::endTransaction(void)
{
}

/**
  * @brief  Deinitialize the SPI instance and stop it.
  */
void SPIClass::end(void)
{
  tls_gpio_cfg(WM_IO_PB_15, WM_GPIO_DIR_OUTPUT, WM_GPIO_ATTR_PULLLOW);
  tls_gpio_cfg(WM_IO_PB_16, WM_GPIO_DIR_OUTPUT, WM_GPIO_ATTR_PULLLOW);
  tls_gpio_cfg(WM_IO_PB_17, WM_GPIO_DIR_OUTPUT, WM_GPIO_ATTR_PULLLOW);
  tls_gpio_cfg(WM_IO_PB_18, WM_GPIO_DIR_OUTPUT, WM_GPIO_ATTR_PULLLOW);
}

/**
  * @brief  Deprecated function.
  *         Configure the bit order: MSB first or LSB first.
  * @param  _bitOrder: MSBFIRST or LSBFIRST
  */
void SPIClass::setBitOrder(BitOrder _bitOrder)
{
  if (_bitOrder == MSBFIRST)
  {
    spi_set_endian(1);
  }
  else
  {
    spi_set_endian(0);
  }
}

/**
  * @brief  Deprecated function.
  *         Configure the data mode (clock polarity and clock phase)
  * @param  _mode: SPI_MODE0, SPI_MODE1, SPI_MODE2 or SPI_MODE3
  * @note
  *         Mode          Clock Polarity (CPOL)   Clock Phase (CPHA)
  *         SPI_MODE0             0                     0
  *         SPI_MODE1             0                     1
  *         SPI_MODE2             1                     0
  *         SPI_MODE3             1                     1
  */
void SPIClass::setDataMode(uint8_t _mode)
{
  uint8_t mode;

  if (SPI_MODE0 == _mode)
  {
    mode = TLS_SPI_MODE_0;
  }
  else if (SPI_MODE1 == _mode)
  {
    mode = TLS_SPI_MODE_1;
  }
  else if (SPI_MODE2 == _mode)
  {
    mode = TLS_SPI_MODE_2;
  }
  else if (SPI_MODE3 == _mode)
  {
    mode = TLS_SPI_MODE_3;
  }
  spi_set_mode(mode);
}
void SPIClass::setFrequency(uint32_t freq)
{
  spi_set_sclk(freq);
}

/**
  * @brief  Deprecated function.
  *         Configure the clock speed.
  */
void SPIClass::setClockDivider(uint8_t _divider)
{
}

/**
  * @brief  Transfer one byte on the SPI bus.
  *         begin() or beginTransaction() must be called at least once before.
  * @param  data: byte to send.
  * @return byte received from the slave.
  */
uint8_t SPIClass::transfer(uint8_t data)
{
  uint8_t rxdata = 0;

  tls_spi_write(&data, 1);
  tls_spi_read(&rxdata, 1);
  return rxdata;    
}

/**
  * @brief  Transfer two bytes on the SPI bus in 16 bits format.
  * @param  data: bytes to send.
  * @return bytes received from the slave in 16 bits format.
  */
uint16_t SPIClass::transfer16(uint16_t data)
{
  uint16_t rxdata = 0;

  tls_spi_write((uint8_t *)&data, 2);
  tls_spi_read((uint8_t *)&rxdata, 2);

  return rxdata;
}

/**
  * @brief  Transfer several bytes.
  * @param  _buf: pointer to the bytes to send. 
  * @param  _count: number of bytes to send
  */
void SPIClass::transferWrite(void *_buf, size_t _count)
{
  tls_spi_write((uint8_t *)_buf, _count);
}
/**
  * @brief  Transfer several bytes. 
  * @param  _buf: pointer to the bytes to received.
  * @param  _count: number of bytes to receive.
  */
void SPIClass::transferRead(void *_buf, size_t _count)
{
  tls_spi_read((uint8_t *)_buf, _count);
}
/**
  * @brief  Transfer several bytes. Only one buffer used to send and receive data.
  * @param  _buf: pointer to the bytes to send. The bytes received are copy in
  *         this buffer.
  * @param  _count: number of bytes to send/receive.
  */
void SPIClass::transfer(void *_buf, size_t _count)
{
  tls_spi_write((uint8_t *)_buf, _count);
  tls_spi_read((uint8_t *)_buf, _count);
}

/**
  * @brief  Transfer several bytes. One buffer contains the data to send and
  *         another one will contains the data received. 
  * @param  _bufout: pointer to the bytes to send.
  * @param  _bufin: pointer to the bytes received.
  * @param  _count: number of bytes to send/receive.
  */
void SPIClass::transfer(void *_bufout, void *_bufin, size_t _count)
{
  if (_bufout != NULL)
  {
    tls_spi_write((uint8_t *)_bufout, _count);
  }
  if (_bufin != NULL)
  {
    tls_spi_read((uint8_t *)_bufin, _count);
  }
}

/**
  * @brief  Not implemented.
  */
void SPIClass::usingInterrupt(uint8_t interruptNumber)
{
}

/**
  * @brief  Not implemented.
  */
void SPIClass::attachInterrupt(void)
{
  // Should be enableInterrupt()
}

/**
  * @brief  Not implemented.
  */
void SPIClass::detachInterrupt(void)
{
  // Should be disableInterrupt()
}
