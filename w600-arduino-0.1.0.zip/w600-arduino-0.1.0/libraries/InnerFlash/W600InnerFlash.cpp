#include <string.h>
#include <stdio.h>

#include "W600InnerFlash.h"

extern "C" {
#include "wm_internal_flash.h"
#include "wm_params.h"
}

W600InnerFlashClass  InnerFlash;

#define INNER_FLASH_BASE_ADDR (0x8000000)
#define INNER_FLASH_SECTOR_SIZE  (0x1000)

int W600InnerFlashClass::begin()
{
	int rc = tls_fls_init();
	return rc == 0;
}

bool W600InnerFlashClass::flashEraseSector(uint32_t sector)
{
    int rc = tls_fls_erase((sector)
                | (INNER_FLASH_BASE_ADDR / INNER_FLASH_SECTOR_SIZE));
    return rc == 0;
}

bool W600InnerFlashClass::flashWrite(uint32_t offset, uint8_t *data, size_t size)
{
    int rc = tls_fls_write(offset | INNER_FLASH_BASE_ADDR,
                (uint8_t*)data, size);
    return rc == 0;
}

bool W600InnerFlashClass::flashRead(uint32_t offset, uint8_t *data, size_t size)
{
    int rc = tls_fls_read(offset | INNER_FLASH_BASE_ADDR,
                (uint8_t*)data, size);
    return rc == 0;
}


