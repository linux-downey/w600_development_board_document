#ifndef _INNER_FLASH_H_
#define _INNER_FLASH_H_

#include <stdio.h>
#include <stdint.h>

extern "C" {
#include "wm_type_def.h"
}

class W600InnerFlashClass
{
    public:
	    int  begin();
        bool flashEraseSector(uint32_t sector);
        bool flashWrite(uint32_t offset, uint8_t *data, size_t size);
        bool flashRead(uint32_t offset, uint8_t *data, size_t size);

};

extern W600InnerFlashClass  InnerFlash;
#endif