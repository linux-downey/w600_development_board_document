#ifndef _DNS_SERVER_H_
#define _DNS_SERVER_H_

#include <stdint.h>

class DNSServer
{
public:
    //void processNextRequest();
    //void setErrorReplyCode(const DNSReplyCode &replyCode);
    //void setTTL(const uint32_t &ttl);

    bool start(const uint16_t &port,
                const char *domainName,
                const char *resolvedIP);
    bool start(const char *domainName);
    void stop();

private:
    //void downcaseAndRemoveWwwPrefix(const char *domainName);
    //char *getDomainNameWithoutWwwPrefix();
    //bool requestIncludesOnlyOneQuestion();
    //void replyWithIP();
    //void replyWithCustomCode();
};
#endif
