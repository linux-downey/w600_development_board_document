#include <stdio.h>
#include <string.h>

#include "wiring_time.h"
#include "W600WiFiOneshot.h"
#include "W600WiFi.h"

extern "C" {
#include "wm_wifi.h"
#include "wm_wifi_oneshot.h"
#include "wm_mem.h"
#include "wm_osal.h"
}



int WiFiOneshotClass::oneshotStart()
{
	tls_wifi_set_oneshot_flag(1);
}

int WiFiOneshotClass::oneshotStop()
{
	tls_wifi_set_oneshot_flag(0);
}


int WiFiOneshotClass::oneshotGetState()
{
	return tls_wifi_get_oneshot_flag();
}

int WiFiOneshotClass::oneshotSetMode(ONESHOT_MODE mode)
{
	tls_wifi_set_oneshot_config_mode(mode);
}


int WiFiOneshotClass::oneshotGetMode()
{
	return tls_wifi_get_oneshot_config_mode();
}


