#ifndef _WIRING_WIFI_AP_H_
#define _WIRING_WIFI_AP_H_

#include <stdint.h>

class WiFiAPClass
{
public:
    bool softAP(const char * ssid, const char *passphrase = NULL,
            int channel = 1, int ssid_hidden = 0, int max_connection = 4);
    bool softAPConfig(uint32_t local_ip, uint32_t gateway, uint32_t subnet);
    bool softAPConfig(const char * local_ip, const char *gateway, const char *subnet);
    bool softAPdisconnect(bool wifioff = false);
    bool softAPdestroy();

    uint8_t softAPgetStationNum();

    char * softAPIP();

    uint8_t * softAPmacAddress(uint8_t *mac);
    char * softAPmacAddress(void);

    char * softAPSSID() const;
    char * softAPPSK() const;
};

#endif
