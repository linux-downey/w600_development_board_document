#ifndef _WIRING_WIFIONESHOT_H_
#define _WIRING_WIFIONESHOT_H_

#include <stdint.h>

enum ONESHOT_MODE {  
        ONESHOT_UDP  = 0,
        ONESHOT_SOCKET = 1,			/*AP+socket*/
        ONESHOT_WEBSERVER = 2,		/*AP+WEBSERVER*/
};

class WiFiOneshotClass
{
public:
    int oneshotStart();
	int oneshotStop();
	int oneshotGetState();
	int oneshotSetMode(ONESHOT_MODE mode);
	int oneshotGetMode();
};

#endif
