#ifndef _WIRING_WIFISTA_H_
#define _WIRING_WIFISTA_H_

#include <stdio.h>

extern "C" {
#include "wm_wifi.h"
}

#include "IPAddress.h"

typedef enum {
    WL_IDLE_STATUS      = 0,
    WL_NO_SSID_AVAIL    = 1,
    WL_SCAN_COMPLETED   = 2,
    WL_CONNECTED        = 3,
    WL_CONNECT_FAILED   = 4,
    WL_CONNECTION_LOST  = 5,
    WL_DISCONNECTED     = 6,
    WL_NO_SHIELD        = 7
} wl_status_t;

class WiFiSTAClass
{
public:
    int begin(const char *ssid, const char * passphrase = NULL,
        	unsigned int channel = 0, const unsigned char bssid[6] = NULL,
        	bool connect = true);
    int begin(char *ssid, char *passphrase = NULL,
        	int channel = 0, unsigned char bssid[6] = NULL,
        	bool connect = true);
    int begin();

#if USER_CONSTRUCTOR
    bool config(IPAddress local_ip, IPAddress gateway, IPAddress subnet,
       	    IPAddress dns1 = (unsigned int)0x00000000, IPAddress dns2 = (unsigned int)0x00000000);
#endif
    bool reconnect();
	bool disconnect(bool wifioff = false);
    bool isConnected();

    bool setAutoConnect(bool autoConnect);
    bool getAutoConnect();

    bool setAutoReconnect(bool autoReconnect);
    bool getAutoReconnect();
    
	uint8_t waitForConnectResult();

    IPAddress localIP();

    //uint8_t *macAddress(uint8_t *mac);
    char *macAddress();
    char *macAddressStr();
    //unsigned char *macAddress(unsigned char *mac);

    IPAddress subnetMask();
    IPAddress getwayIP();
    IPAddress dnsIP(uint8_t dns_no = 0);

    char *hostname();
    bool hostname(char *aHostname);
    bool hostname(const char *aHostname);

    wl_status_t status();
    char *statusStr();
    char *SSID() const;
    char *psk() const;

    uint8_t *BSSID();
    char *BSSIDstr();

    int32_t RSSI();

private:
    wl_status_t wstatus;
};

#endif
