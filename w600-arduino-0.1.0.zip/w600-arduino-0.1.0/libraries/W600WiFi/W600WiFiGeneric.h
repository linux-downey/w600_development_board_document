#ifndef _WIRING_WIFI_GENERIC_H_
#define _WIRING_WIFI_GENERIC_H_

#include <stdint.h>

#include "W600WiFiType.h"
#include "IPAddress.h"

class WiFiGenericClass
{
public:
    int32_t channel(void);
    bool setSleepMode();

    WiFiMode_t getMode();

    bool enableSTA(bool enable);
    bool enableAP(bool enable);

    bool forceSleepBegin(uint32_t sleepUs = 0);
    bool forceSleepWake();

    int hostByName(const char* aHostname, IPAddress& aResult);
    int hostByName(const char* aHostname, IPAddress& aResult, uint32_t timeout_ms);
};

#endif
