#include "W600WiFi.h"

WiFiClass WiFi;

