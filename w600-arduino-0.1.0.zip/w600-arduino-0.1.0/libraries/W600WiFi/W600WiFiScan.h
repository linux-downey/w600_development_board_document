#ifndef _WIRING_WIFISCAN_H_
#define _WIRING_WIFISCAN_H_

#include <stdint.h>

/* Encryption modes */
enum wl_enc_type {  /* Values map to 802.11 encryption suites... */
    ENC_TYPE_WEP  = 5,
    ENC_TYPE_TKIP = 2,
    ENC_TYPE_CCMP = 4,
    /* ... except these two, 7 and 8 are reserved in 802.11-2007 */
    ENC_TYPE_NONE = 7,
    ENC_TYPE_AUTO = 8
};


class WiFiScanClass
{
public:
    int8_t scanNetworks(
                bool async = false, bool show_hidden = false,
                uint8_t channel = 0, uint8_t* ssid = NULL);
    /*
    void scanNetworksAsync(
                std::function<void(int)>onComplete, bool show_hidden = flase);
    */
    int8_t scanComplete();
    void scanDelete();

    bool getNetworkInfo(uint8_t networkItem, char *&ssid, uint8_t &encryptionType,
                int32_t &RSSI, uint8_t *&BSSID, int32_t &channel, bool &isHidden);
    char * SSID(uint8_t networkItem);
    uint32_t encryptionType(uint8_t networkItem);
    int32_t RSSI(uint8_t networkItem);
    uint8_t * BSSID(uint8_t networkItem);
    char * BSSIDstr(uint8_t networkItem);
    int32_t channel(uint8_t networkItem);
    bool isHidden(uint8_t networkItem);

protected:
    static void _scanDone();
    static void * _getScanInfoByIndex(int i);
};

#endif
