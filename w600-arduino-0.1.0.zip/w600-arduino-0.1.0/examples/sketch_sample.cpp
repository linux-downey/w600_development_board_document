#include <W600WiFi.h>
//#include <WiFiClient.h>
//#include <WiFiServer.h>
//#include <WiFiUdp.h>

//#include <SPI.h>
#define W600_INNERFLASH_EXAMPLE  0   /*set this macro to test inner flash operation*/
#if W600_INNERFLASH_EXAMPLE
#include <W600InnerFlash.h>
#endif
#define TEST_DNS_CLIENT 0
#if TEST_DNS_CLIENT
#include <Dns.h>
#endif

#include <DNSServer.h>
#include <WiFiServer.h>


#include <Arduino.h>

#define GCC_W600_ARDUINO         1

#define SSID_NAME  "123456789"
#define PASSWORD  "kobe19780823"

int test_println_i()
{
    int inum = 10;
    Serial.println(inum);
    Serial.println(inum, DEC);
    Serial.println(inum, HEX);
    Serial.println(inum, OCT);
    Serial.println(inum, BIN);
}

int test_println_ui()
{
    unsigned int uinum = 10;
    Serial.println(uinum);
    Serial.println(uinum, DEC);
    Serial.println(uinum, HEX);
    Serial.println(uinum, OCT);
    Serial.println(uinum, BIN);
}

int test_println_l()
{
    long lnum = 10;
    Serial.println(lnum);
    Serial.println(lnum, DEC);
    Serial.println(lnum, HEX);
    Serial.println(lnum, OCT);
    Serial.println(lnum, BIN);
}

int test_println_ul()
{
    unsigned ulnum = 10;
    Serial.println(ulnum);
    Serial.println(ulnum, DEC);
    Serial.println(ulnum, HEX);
    Serial.println(ulnum, OCT);
    Serial.println(ulnum, BIN);
}

int test_println_f()
{
    double dnum = 123.456;
    Serial.println(dnum);
    Serial.println(dnum, DEC);
    Serial.println(dnum, HEX);
    Serial.println(dnum, OCT);
    Serial.println(dnum, BIN);
}

#if GCC_W600_ARDUINO
int wifi_connect_as_sta()
{
  //char mac[64] = {0};
  printf("WiFi.mac: %s\n", WiFi.macAddressStr());
  //Serial.println("WiFi");
  WiFi.begin((const char *)"123456789", (const char *)"kobe19780823");
  int status = 0;
 // do
  //{
    status = WiFi.status();
    delay(500);
    Serial.print(".");
    printf("status: %d\n", status);
  //  } while (WL_CONNECTED != status);
    Serial.println();
    delay(5000);

    printf("-----------------------\n");
    Serial.println(String("IPv4 Address: ") + WiFi.localIP().toString());
    printf("-----------------------\n");
    printf("IPv4 Netmask: ");
    Serial.println(WiFi.subnetMask());
    printf("IPv4 GateWay: ");
    Serial.println(WiFi.getwayIP());
    printf("IPv4 DNS: ");
    Serial.println(WiFi.dnsIP());
    printf("IPv4 DNS1: ");
    Serial.println(WiFi.dnsIP(1));

    printf("current SSID: %s\n", WiFi.SSID());
    printf("current Passphrase: %s\n", WiFi.psk());
    printf("connected BSSID(str): %s\n", WiFi.BSSIDstr());
    printf("current RSSI: %d\n", WiFi.RSSI());

    unsigned char *pbssid = (unsigned char *)(WiFi.BSSID());
    printf("connected BSSID: %02X:%02X:%02X:%02X:%02X:%02X\n",
          pbssid[0], pbssid[1], pbssid[2], pbssid[3], pbssid[4], pbssid[5]);
    printf("WiFi Connected ?[%s]\n", WiFi.isConnected() ? "true" : "false");
    printf("reconnect...\n");
    WiFi.reconnect();
    printf("WiFi status: %d/%s\n", WiFi.status(), WiFi.statusStr());
    WiFi.waitForConnectResult();
    printf("WiFi status: %d/%s\n", WiFi.status(), WiFi.statusStr());
    delay(3000);
    Serial.println("IPv4 Address: " + WiFi.localIP());
    printf("before AutoReconnect: %s\n", WiFi.getAutoReconnect() ? "true" : "false");
    WiFi.setAutoReconnect(true);
    printf("after TRUE AutoReconnect: %s\n", WiFi.getAutoReconnect() ? "true" : "false");
    WiFi.setAutoReconnect(false);
    printf("after FALSE AutoReconnect: %s\n", WiFi.getAutoReconnect() ? "true" : "false");
  }

int test_wifi_scan_each_func(int idx)
{
  //char ssid[33] = {0};
  //unsigned char bssid[128] = {0};
  char *ssid = NULL;
  unsigned char * bssid = NULL;
  char *bssid_str = NULL;
  char enc = -1;
  int rssi = -1;
  int channel = 0;
  bool hidden;
      enc = -1;rssi = 0;channel = 0;hidden = false;
      ssid = NULL, bssid = NULL; bssid_str = NULL;
            rssi = WiFi.RSSI(idx);
      ssid = WiFi.SSID(idx);
      enc = WiFi.encryptionType(idx);
      rssi = WiFi.RSSI(idx);
      bssid = (unsigned char*)WiFi.BSSID(idx);
      bssid_str = WiFi.BSSIDstr(idx);
      channel = WiFi.channel(idx);
  printf("AP: %d, ssid: %s, enc: %d, rssi: %d, bssid: %02X:%02X:%02X:%02X:%02X:%02X, channel: %d, hidden: %d/%s\n",
    idx, ssid, enc, rssi,
    bssid[0], bssid[1], bssid[2], bssid[3], bssid[4], bssid[5],
    channel, hidden, hidden ? "true" : "false");
      //printf("BSSID:%s,SSID:%s,RSSI:%d,CHL:%d\n", bssid_str, ssid, rssi, channel);
      #if 0
      printf("AP(%d):\n", idx);
      printf("    SSID: %s\n", ssid);
      /*
      printf("    SSID: %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",
        ssid[0], ssid[1], ssid[2], ssid[3], ssid[4], ssid[5], ssid[6], ssid[7], 
        ssid[8], ssid[9], ssid[10], ssid[11], ssid[12], ssid[13], ssid[14], ssid[15], 
        ssid[16], ssid[17], ssid[18], ssid[19], ssid[20], ssid[21], ssid[22], ssid[23], 
        ssid[24], ssid[25], ssid[26], ssid[27], ssid[28], ssid[29], ssid[30], ssid[31]);
        */
      printf("    BSSID: %02X:%02X:%02X:%02X:%02X:%02X\n", bssid[0], bssid[1], bssid[2], bssid[3], bssid[4], bssid[5]);
      printf("    BSSIDstr: %s\n", bssid_str);
      printf("    enc: %d\n", enc);
      printf("    rssi: %d\n", rssi);
      printf("    channel: %d\n", channel);
      printf("    hidden: %d/%s\n", hidden, hidden ? "true" : "false");
      delay(1000);
      #endif
  }

int test_wifi_scan_via_only1(int idx)
{
  char *ssid = NULL;
  int enc = 0;
  int rssi = 0;
  unsigned char * bssid = NULL;
  int channel = 0;
  bool hidden = false;
  WiFi.getNetworkInfo(
    (uint8_t)idx,
    (char *&)ssid,
    (uint8_t&)enc, (int32_t&)rssi, (uint8_t*&)bssid, (int32_t&)channel, (bool&)hidden);
  printf("AP: %d, ssid: %s, enc: %d, rssi: %d, bssid: %02X:%02X:%02X:%02X:%02X:%02X, channel: %d, hidden: %d/%s\n",
    idx, ssid, enc, rssi,
    bssid[0], bssid[1], bssid[2], bssid[3], bssid[4], bssid[5],
    channel, hidden, hidden ? "true" : "false");
  }
int wifi_scan()
{
  printf("[%s %s %d]\n", strrchr(__FILE__, '\\') + 1, __func__, __LINE__);
  int cnt = -1;
  int idx = 0;
  
  WiFi.scanNetworks();
  do
  {
    cnt = WiFi.scanComplete();
    Serial.print('.');
    delay(500);
    } while (cnt < 0);
  printf("[%s %s %d] cnd: %d\n", strrchr(__FILE__, '\\') + 1, __func__, __LINE__, cnt);
    for (idx = 0; idx < cnt; idx++)
    {
      //test_wifi_scan_each_func(idx);
      test_wifi_scan_via_only1(idx);
      }
      printf("--------------------------------------------------\n");
    for (idx = 0; idx < cnt; idx++)
    {
      test_wifi_scan_each_func(idx);
    }
  }

int start_wifi_as_ap()
{
  Serial.println("start_wifi_as_ap");
  WiFi.softAP("ABCDEFG", "1234567890");
  //WiFi.softAP("ABCDEFG");
  }

  DNSServer dnsServer;
WiFiServer wifiserv(2345);
void wifiserver_setup()
{
  Serial.println("wifiserver_setup");
  wifiserv.begin();
}

#if W600_INNERFLASH_EXAMPLE
void innerflash_setup()
{
   InnerFlash.begin();
}
#endif
  
void w600_arduino_setup()
{
  printf("[%s %s %d]\n", __FILE__, __func__, __LINE__);
#if W600_INNERFLASH_EXAMPLE
  innerflash_setup();
#endif
  Serial.println("xxxxxxxxxxxx");
  //Serial1.begin();
  SerialM1.begin();
  wifi_connect_as_sta();
  //start_wifi_as_ap();
  delay(1000);
  //dnsServer.start("www.w600.com");
  //wifi_scan();
  //wifiserver_setup();
  
}

int test_pin_ab_out(char *name, int pin)
{
  printf("set pin %s OUTPUT\n", name);
  pinMode(pin, OUTPUT);
  printf("  LOW %s for 10 seconds ...\n", name);
    digitalWrite(pin, LOW);
    delay(10000);
  printf("  HIGH %s for 10 seconds ...\n", name);
    digitalWrite(pin, HIGH);
    delay(10000);
  printf("  LOW %s for 10 seconds ...\n", name);
    digitalWrite(pin, LOW);
    delay(10000);
  printf("  HIGH %s \n", name);
    digitalWrite(pin, HIGH);
    delay(9000);
  }

int test_pin_all_out()
{
    //test_pin_ab("PIN_A4", PIN_A4);
    test_pin_ab_out("PIN_A5", PIN_A5);
    //test_pin_ab_out("PIN_B6", PIN_B6);
    //test_pin_ab_out("PIN_B7", PIN_B7);
    //test_pin_ab_out("PIN_B8", PIN_B8);
    //test_pin_ab_out("PIN_B9", PIN_B9);
    //test_pin_ab_out("PIN_B10", PIN_B10);
    test_pin_ab_out("PIN_B11", PIN_B11);
    //test_pin_ab_out("PIN_B12", PIN_B12);
  }

int test_pin_ab_input(char *name, int pin)
{
  int val;
  printf("set pin %s INPUT after 5 seconds\n", name);
    delay(5000);
  printf("set pin PIN_A1 HIGH & sleep 3 seconds\n");
    digitalWrite(PIN_A1, HIGH);
    delay(3000);
  pinMode(pin, INPUT);
  val = digitalRead(pin);
  printf(" read pin %s value: %d\n", name, val);
    delay(10000);
  printf("set pin PIN_A1 LOW & sleep 3 seconds\n");
    digitalWrite(PIN_A1, LOW);
    delay(3000);
  val = digitalRead(pin);
  printf(" read pin %s value: %d\n", name, val);
    delay(9000);
  }

  int test_pin_ab_pa1(char *name, int pin)
{
  int val;
  name = "PIN_A1";
  pin = PIN_A1;
  pinMode(PIN_A5, OUTPUT);
  printf("set pin %s INPUT after 5 seconds\n", name);
    delay(5000);
  printf("  set pin PIN_A5 HIGH & sleep 3 seconds\n");
    digitalWrite(PIN_A5, HIGH);
    delay(3000);
  pinMode(pin, INPUT);
  val = digitalRead(pin);
  printf(" read pin %s value: %d\n", name, val);
    delay(10000);
  printf("set pin PIN_A5 LOW & sleep 3 seconds\n");
    digitalWrite(PIN_A5, LOW);
    delay(3000);
  val = digitalRead(pin);
  printf(" read pin %s value: %d\n", name, val);
    delay(9000);
  }
int test_all_pin_input()
{
  //test_pin_ab_input("PIN_A4", PIN_A4);
  //test_pin_ab_input("PIN_A5", PIN_A5);
 // test_pin_ab_input("PIN_B6", PIN_B6);
  //test_pin_ab_input("PIN_B7", PIN_B7);
 // test_pin_ab_input("PIN_B8", PIN_B8);
  ///test_pin_ab_input("PIN_B9", PIN_B9);
  //test_pin_ab_input("PIN_B10", PIN_B10);
  test_pin_ab_input("PIN_B11", PIN_B11);
  test_pin_ab_input("PIN_B12", PIN_B12);
  }
int test_pin()
{
 // test_pin_ab_pa1("PIN_A1", PIN_A1);
 // pinMode(PIN_A1, OUTPUT);
  //  digitalWrite(PIN_A1, HIGH);
  //  test_all_pin_input();
}

int test_println()
{
    Serial.println();
    Serial.println('A');
    Serial.println('a');
    Serial.println('a', DEC);
    Serial.println('a', HEX);
    Serial.println('a', OCT);
    Serial.println('a', BIN);

    test_println_i();
    test_println_ui();
    test_println_l();
    test_println_ul();
    test_println_f();
}

int only_light_r()
{
      digitalWrite(LED_RED, LOW);
      digitalWrite(LED_GREEN, HIGH);
      digitalWrite(LED_BLUE, HIGH);
  }
int only_light_g()
{
      digitalWrite(LED_RED, HIGH);
      digitalWrite(LED_GREEN, LOW);
      digitalWrite(LED_BLUE, HIGH);
  }
int only_light_b()
{
      digitalWrite(LED_RED, HIGH);
      digitalWrite(LED_GREEN, HIGH);
      digitalWrite(LED_BLUE, LOW);
  }
  
int get_AP_info()
{
  printf("-----------------------------------------\n");
  printf("STANUM: %d\n", WiFi.softAPgetStationNum());
  printf("AP IP: %s\n", WiFi.softAPIP());
  printf("AP MAC: %s\n", WiFi.softAPmacAddress());
  printf("AP SSID: %s\n", WiFi.softAPSSID());
  printf("AP PSK: %s\n", WiFi.softAPPSK());
  }
  
int test_USER_BTN()
{
  pinMode(PIN_B7, INPUT);
  int val = 1;
  int val_prev = 2;
      pinMode(WM_IO_PB_17, OUTPUT);
      pinMode(WM_IO_PB_16, OUTPUT);
      pinMode(WM_IO_PB_18, OUTPUT);
      int start_ap = 0;
  while (1)
  {
    val = digitalRead(PIN_B7);
    if (val != val_prev)
    {
      printf("USET BTN: %d\n", val);
      val_prev = val;
      }
    if (0 == val)
    {
      if ( 0 == start_ap ) {
      WiFi.softAP("ABCDEFG", "1234567890");
      start_ap = 1;
      }
      only_light_r();
      delay(800);
      only_light_g();
      delay(800);
      only_light_b();
      delay(800);
      get_AP_info();
      }
    else
    {
      if (1 == start_ap)
      {
        Serial.println("Disconnect AP");
      WiFi.softAPdestroy();
      start_ap = 0;
      }
      digitalWrite(WM_IO_PB_16, HIGH);
      digitalWrite(WM_IO_PB_17, HIGH);
      digitalWrite(WM_IO_PB_18, HIGH);
      }
    }    
  }

#if W600_INNERFLASH_EXAMPLE
void innerflash_loop()
{
  u8 data[4096];
  int i = 0;

  InnerFlash.flashRead(240*4096, &data[0], 4096);
  if (data[0] == 0xAA)
  {
    InnerFlash.flashEraseSector(240);
    memset(&data[0], 0xAA, 4096);
    InnerFlash.flashRead(240*4096, &data[0], 4096);
    for (i = 0; i< 4096; i++)
    {
      if (data[i] == 0xFF)
      {
         continue;
      }
    }
    if (i == 4096)
    {
      printf("erase ok\n");
    }
  }else{
    memset(&data[0], 0xAA, 4096);
    InnerFlash.flashWrite(240*4096, &data[0], 4096);
    memset(&data[0], 0xFF, 4096);
    InnerFlash.flashRead(240*4096, &data[0], 4096);
    for (i = 0; i< 4096; i++)
    {
      if (data[i] == 0xAA)
      {
         continue;
      }
    }
    if (i == 4096)
    {
      printf("write ok\n");
    }
  }
}
#endif
  
void w600_arduino_loop()
{
  printf("loop()\n");
#if W600_INNERFLASH_EXAMPLE
  innerflash_loop();
#endif  
  #if TEST_DNS_CLIENT
  DNSClient dns;
  char *resolve = NULL;
  if (dns.getHostByName("www.baidu.com", resolve))
  {
    printf("www.baidu.com: %s\n", resolve);
  }
  #endif
  //Serial1.println('A');
  //Serial1.read();
  SerialM1.write('A');
  printf("before read, SerialM1.available: %d\n", SerialM1.available());
 // if (SerialM1.available())
   // printf("SerialM1.parseInt(): %d\n", SerialM1.parseInt());
 // if (SerialM1.available())
 //   printf("SerialM1.parseFloat(): %f\n", SerialM1.parseFloat());
   char buf[10] = {0};
   if (SerialM1.available() && 0)
   {
   SerialM1.readBytes(buf, 10);
   buf[10 - 1] = '\0';
   printf("buf: %s\n", buf);
   }
   if (SerialM1.available())
   {
   SerialM1.readBytesUntil('A', buf, 10);
   buf[10 - 1] = '\0';
   printf("buf: %s\n", buf);
   }
  printf("SerialM1.find(\"12345\"): %d\n", SerialM1.find("12345"));
  printf("SerialM1.find(\"ABCDE\"): %d\n", SerialM1.find("ABCDE"));
  while (0 != SerialM1.available())
  {
  SerialM1.peek();
  SerialM1.read();
  }
  printf("after read, SerialM1.available: %d\n", SerialM1.available());
  //get_AP_info();
#if 0
  test_USER_BTN();
  test_println();
#endif
  // put your main code here, to run repeatedly:
  //Serial.test_test();
#if 0
  printf("[%s %s %d] &pppp: %p\n", __FILE__, __func__, __LINE__, &pppp);
 int *p = (int *)&pppp;
  printf("[%s %s %d] *&pppp + 0: 0x%08x\n", __FILE__, __func__, __LINE__, *p);
  p++;
  printf("[%s %s %d] *&pppp + 4 * 1: 0x%08x\n", __FILE__, __func__, __LINE__, *p++);
  printf("[%s %s %d] *&pppp + 4 * 2: 0x%08x\n", __FILE__, __func__, __LINE__, *p++);
  printf("[%s %s %d] *&pppp + 4 * 3: 0x%08x\n", __FILE__, __func__, __LINE__, *p++);
  printf("[%s %s %d] *&pppp + 4 * 4: 0x%08x\n", __FILE__, __func__, __LINE__, *p++);
  printf("[%s %s %d] *&pppp + 4 * 5: 0x%08x\n", __FILE__, __func__, __LINE__, *p++);
  printf("[%s %s %d] *&pppp + 4 * 6: 0x%08x\n", __FILE__, __func__, __LINE__, *p++);
  printf("[%s %s %d] *&pppp + 4 * 7: 0x%08x\n", __FILE__, __func__, __LINE__, *p++);
  printf("[%s %s %d] *&pppp + 4 * 8: 0x%08x\n", __FILE__, __func__, __LINE__, *p++);
  printf("[%s %s %d] *&pppp + 4 * 9: 0x%08x\n", __FILE__, __func__, __LINE__, *p++);
  pppp.test_test();
#endif
  Serial.println("Hello From W600_EV Board Serial\n");
  test_pin();
  int sleep_cnt = 60;
  int i = 0;
  for (i = 1; i <= sleep_cnt ; i++)
  {
    if ((i - 1) % 20 == 0)
    {
       Serial.println();
      }
    else if ((i-1) % 10 == 0)
    {
      Serial.print("   ");
    }
    else if ((i-1) % 5 == 0)
    {
      Serial.print(' ');
    }
    Serial.print('.');
    delay(1000);
  }
  Serial.println();
}
#endif

void setup() {
  printf("setup()\n");
  // put your setup code here, to run once:
  w600_arduino_setup();
}

void loop() {
  printf("[%s %s %d]\n", __FILE__, __func__, __LINE__);
  w600_arduino_loop();
}
