#include <W600WiFi.h>

#define TEST_DNS_CLIENT 1
#if TEST_DNS_CLIENT
#include <Dns.h>
#endif

#include <Arduino.h>

int wifi_connect_as_sta()
{
  //char mac[64] = {0};
  printf("WiFi.mac: %s\n", WiFi.macAddressStr());
  //Serial.println("WiFi");
  WiFi.begin((const char *)"123456789", (const char *)"kobe19780823");
  int status = 0;
  do
  {
    status = WiFi.status();
    delay(500);
    Serial.print(".");
    } while (WM_WIFI_JOINED != status);
    Serial.println();
    delay(5000);

    printf("IPv4 Address: %s\n", WiFi.localIP());
    printf("IPv4 Netmask: %s\n", WiFi.subnetMask());
    printf("IPv4 GateWay: %s\n", WiFi.getwayIP());
    printf("IPv4 DNS: %s\n", WiFi.dnsIP());
    printf("IPv4 DNS1: %s\n", WiFi.dnsIP(1));

    printf("current SSID: %s\n", WiFi.SSID());
    printf("current Passphrase: %s\n", WiFi.psk());
    printf("connected BSSID(str): %s\n", WiFi.BSSIDstr());
    printf("current RSSI: %d\n", WiFi.RSSI());

    unsigned char *pbssid = (unsigned char *)(WiFi.BSSID());
    printf("connected BSSID: %02X:%02X:%02X:%02X:%02X:%02X\n",
          pbssid[0], pbssid[1], pbssid[2], pbssid[3], pbssid[4], pbssid[5]);
    printf("WiFi Connected ?[%s]\n", WiFi.isConnected() ? "true" : "false");
    printf("reconnect...\n");
    WiFi.reconnect();
    printf("WiFi status: %d/%s\n", WiFi.status(), WiFi.statusStr());
    WiFi.waitForConnectResult();
    printf("WiFi status: %d/%s\n", WiFi.status(), WiFi.statusStr());
    delay(3000);
    printf("IPv4 Address: %s\n", WiFi.localIP());
    printf("before AutoReconnect: %s\n", WiFi.getAutoReconnect() ? "true" : "false");
    WiFi.setAutoReconnect(true);
    printf("after TRUE AutoReconnect: %s\n", WiFi.getAutoReconnect() ? "true" : "false");
    WiFi.setAutoReconnect(false);
    printf("after FALSE AutoReconnect: %s\n", WiFi.getAutoReconnect() ? "true" : "false");
  }

}

void w600_arduino_setup()
{
  printf("[%s %s %d]\n", __FILE__, __func__, __LINE__);
  Serial.println("xxxxxxxxxxxx");
  //Serial1.begin();
  SerialM1.begin();
  wifi_connect_as_sta();
}

void w600_arduino_loop()
{
  printf("loop()\n");
  #if TEST_DNS_CLIENT
  DNSClient dns;
  char *resolve = NULL;
  if (dns.getHostByName("www.baidu.com", resolve))
  {
    printf("www.baidu.com: %s\n", resolve);
  }
  #endif
  SerialM1.write('A');
  Serial.println("Hello From W600_EV Board Serial\n");
  int sleep_cnt = 60;
  int i = 0;
  for (i = 1; i <= sleep_cnt ; i++)
  {
    if ((i - 1) % 20 == 0)
    {
       Serial.println();
      }
    else if ((i-1) % 10 == 0)
    {
      Serial.print("   ");
    }
    else if ((i-1) % 5 == 0)
    {
      Serial.print(' ');
    }
    Serial.print('.');
    delay(1000);
  }
  Serial.println();
}

void setup() {
  printf("setup()\n");
  // put your setup code here, to run once:
  w600_arduino_setup();
}

void loop() {
  printf("[%s %s %d]\n", __FILE__, __func__, __LINE__);
  w600_arduino_loop();
}
