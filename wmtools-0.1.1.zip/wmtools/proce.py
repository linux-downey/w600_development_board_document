# -*- coding:utf-8 -*-

import pyprind
import time
for pro in pyprind.prog_bar(range(20)):
    time.sleep (0.1)