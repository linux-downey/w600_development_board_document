# -*- coding:utf-8 -*-
#
# W600 flash download script
# Copyright (c) 2018 Winner Micro Electronic Design Co., Ltd.
# All rights reserved.
# 
# Python 3.0    (Special 3.4)
#
# pip install pyserial
# pip install pyprind
# pip install xmodem
#   pip install enum34    # for 2.7
# 
## pip install PyInstaller
## PyInstaller -F download.py
#

import serial
import struct
import platform
import pyprind
import os
import sys, getopt
import time
from xmodem import XMODEM1k
import threading
from time import ctime,sleep
from enum import IntEnum

COM_NAME="COM1"
IMG_FILE="WM_W600_GZ.img"
reset_success=0
#serial_mutex = threading.Lock()

class m_err(IntEnum):
	success = 0,
	err_serial_obj_init = -1,
	err_serial_open = -2,
	err_serial_read = -3

class WMDownload(object):
	
	if platform.system() == 'Windows':
		DEFAULT_PORT = "COM1"
	else:
		DEFAULT_PORT = "/dev/ttyUSB0"
	DEFAULT_BAUD = 115200
	DEFAULT_TIMEOUT = 0.3
	DEFAULT_IMAGE = "../Bin/WM_W600_GZ.img"
	
	def __init__(self, port=DEFAULT_PORT, baud=DEFAULT_BAUD, timeout=DEFAULT_TIMEOUT, image=DEFAULT_IMAGE):
		try:
			self.image = image
			self.ser = serial.Serial(port, baud, timeout=timeout)
			statinfo_bin = os.stat(image)
			self.bar_user = pyprind.ProgBar(statinfo_bin.st_size/1024+2)
		except serial.serialutil.SerialException:
			print('Serial %s is used by other or INIT error' % port)
			sys.exit(m_err['err_serial_obj_init'])
	
	def image_path(self):
		return self.image
	
	def set_port_baudrate(self, baud):
		self.ser.baudrate = baud
	
	def set_timeout(self, timeout):
		self.ser.timeout  = timeout
	
	def getc(self, size, timeout=1):
		try:
			ret=self.ser.read(size)
		except serial.serialutil.SerialException:
			print("OFFline Serial %s" % self.ser.port)
			sys.exit(m_err["err_serial_read"])
		return ret
	
	def putc(self, data, timeout=1):
		self.ser.timeout = timeout
		try:
			self.ser.write(data)
		except serial.serialutil.SerialTimeoutException:
			# do nothing
			# try it again
			return 
		
	def rst_putc(self, data, timeout = 1):
		self.ser.timeout = timeout
		try:
			self.ser.write(data)
		except serial.serialutil.SerialException as err:
			print('[ ', sys._getframe().f_lineno, ' ]', err)
			# do nothing
			# maybe serial is closed
			return
	
	def rst_flushinput(self):
		try:
			self.ser.flushInput()
		except serial.serialutil.SerialException:
			# do nothint
			# maybe serial is closed
			return
	
	def putc_bar(self, data, timeout=1):
		self.ser.timeout = timeout
		self.bar_user.update()
		return self.ser.write(data)
	
	def open(self):
		try:
			self.ser.open()
		except serial.serialutil.SerialException:
			print("Open Serial %s error" % self.ser.port)
			sys.exit(m_err["err_serial_open"])
	
	def close(self):
		self.ser.flush()
		self.ser.flushInput()
		self.ser.close()
	
	def info(self):
		return (self.ser.port , self.ser.baudrate)

def usage():
	print()
	print('USAGE:')
	print('win:python download.py [-c|--console= COM] [-f|--image-file= image]')
	print('Linux:python3 download.py [-c|--console= COM] [-f|--image-file= image]')
	print()
	print('\t-c|--console=    COM         the console used by download function.')
	print('\t                             default：\"COM1\" for windows, \"ttyUSB0\" for linux.')
	print('\t-f|--image-file= IMAGE       the image file used by download function transmitted to the DUT.')
	print('\t                             default: \"../Bin/WM_W600_GZ.img\"')
	print('\t-h|--help                    get this help information')
	print()
	
def get_args():
	opts, args = getopt.getopt(sys.argv[1:], "c:f:h", ["console=", "image-file=", "help"])
	for op, value in opts:
		#print(op)
		if "-c" == op or "--console" == op:
			global COM_NAME
			COM_NAME = value
		elif "-f" == op or "--image-file" == op:
			global IMG_FILE
			IMG_FILE = value
		elif "-h" == op or "--help" == op:
			usage()
			sys.exit()

def restart_w600(serial):
	global reset_success
#	idx=0
	#print(sys._getframe().f_lineno)
	time.sleep(2)
	#print(sys._getframe().f_lineno)
	global serial_mutex
	while True:
		if 0 == reset_success:
#			if serial_mutex.acquire():
			serial.rst_putc(struct.pack('<B', 97))		# 'a'
			serial.rst_putc(struct.pack('<B', 116))		# 't'
			serial.rst_putc(struct.pack('<B', 43))		# '+'
			serial.rst_putc(struct.pack('<B', 122))		# 'z'
			serial.rst_putc(struct.pack('<B', 10))		# '\n'
			serial.rst_flushinput()			# clear input buffer
#			if idx % 4 == 1:
#				print('\r-', end='')
#			elif idx % 4 == 2:
#				print('\r\\', end='')
#			elif idx % 4 == 3:
#				print('\r|', end='')
#				idx=0
#			elif idx % 4 == 0:
#				print('\r/', end='')
#			sys.stdout.flush()
#			idx = idx+1
#				serial_mutex.release()
		else:
			break
	#print(sys._getframe().f_lineno)
	
def wait_for_10_secs():
	print("Please wait for about 10 seconds before module restart ...")
	print("Elapse ", end='')
	for pro in pyprind.prog_bar(range(50)):
		time.sleep(0.2)
	print("FINISH ")
	
def upgrade_firmware(serial):
	print("start upgrade %s "  % serial.image_path())
	try:
		stream = open(serial.image_path(), 'rb+')
	except IOError:
		print("can't open %s file." % serial.image_path())
		serial.close()
		raise
	else:
		serial.set_timeout(1)
		time.sleep(0.2)
		modem = XMODEM1k(serial.getc, serial.putc_bar)
		print("please wait for upgrade ....")
		# try: modem.send() ...
		result = modem.send(stream)
		time.sleep(1)
		print('')
		if result:
			print("upgrade %s image success!" % serial.image_path())
			wait_for_10_secs()
		else:
			print("upgrade %s image fail!" % serial.image_path())
		serial.close()
		
def reset_wm_module(serial):
	thread1 = threading.Thread(target=restart_w600, args=(serial,))
	thread1.setDaemon(True)
	thread1.start()
	global serial_mutex
	
	while True:
#		if serial_mutex.acquire():
		c = serial.getc(1, 0.1)
		#print(c)
		if c == b'C':
			global reset_success
			reset_success=1
			serial.putc(bytes.fromhex('210a00ef2a3100000080841e00'))
			break
		else:
			serial.putc(struct.pack('<B', 27))
#			serial_mutex.release()
	time.sleep(0.5)
			
def main(argv):
	get_args()
	
	download = WMDownload(port=COM_NAME, image=IMG_FILE)
	
	print('')
	print("serial open success！com: %s, baudrate: %s." % download.info())
	print('Waitint for restarting device ...')
	
	download.set_timeout(0.1)
	
	reset_wm_module(download)
	
	download.close()
	time.sleep(0.2)
	download.set_port_baudrate(2000000)
	download.open()
	time.sleep(0.2)
	
	# check baudrate
	while True:
		c = download.getc(1)
		if c == b'C':
			print('serial into high speed mode')
			break
		else:
			download.close()
			download.set_port_baudrate(115200)
			download.open()
			time.sleep(0.2)
			download.putc(bytes.fromhex('210a00ef2a3100000080841e00'))
			download.close()
			download.set_port_baudrate(2000000)
			download.open()
			time.sleep(0.2)
			
	upgrade_firmware(download)
	
if __name__ == '__main__':
    main(sys.argv)
